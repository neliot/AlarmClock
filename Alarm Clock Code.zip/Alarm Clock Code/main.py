import machine 
import time
from ds3231 import DS3231
from oled import Write, GFX, SSD1306_I2C
from oled.fonts import bookerly_12, bookerly_15, bookerly_20
import ssd1306
import _thread
import notes
import gc
spLock = _thread.allocate_lock() 
WIDTH  = 128                                                     # oled display width
HEIGHT = 64
stringTime = []


song_pos = 0
song = [
        notes.note["C4"], 1,
        notes.note["G4"], 1,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["C5"], 1,
        notes.note["G4"], 0.5,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["C5"], 1,
        notes.note["G4"], 0.5,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["F4"], 0.25,
        notes.note["D4"], 1,
        notes.note["G4"], 0.5,
        0, 0.01,
        notes.note["G4"], 0.5,
        
        notes.note["C4"], 1,
        notes.note["G4"], 1,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["C5"], 1,
        notes.note["G4"], 0.5,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["C5"], 1,
        notes.note["G4"], 0.5,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["F4"], 0.25,
        notes.note["D4"], 1,
        notes.note["G4"], 0.5,
        0, 0.01,
        notes.note["G4"], 0.5,
        
        notes.note["A4"], 1,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["C4"], 0.25,
        0, 0.01,
        notes.note["C4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.2,
        notes.note["A4"], 0.2,
        notes.note["B4"], 0.2,
        notes.note["G4"], 0.5,
        0, 0.01,
        notes.note["G4"], 0.5,
        notes.note["A4"], 1,
        notes.note["F4"], 0.25,
        notes.note["E4"], 0.25,
        notes.note["D4"], 0.25,
        notes.note["C4"], 0.25,
        notes.note["G4"], 1,
        notes.note["D4"], 2,
        notes.note["G4"], 1,
    ]

days = ["MON","TUE","WED", "THU", "FRI" ,"SAT", "SUN"]
months = ["JAN" ,"FEB" ,"MAR", "APR", "MAY", "JUN" ,"JUL", "AUG" , "SEP" , "OCT", "NOV", "DEC"]

minimum = [2020 , 1 , 1 , 1, 0, 0, 0]
maximum = [3000, 12, 31, 7, 23, 59,59]
timeSlotOrder = [4, 5, 6, 3, 2, 1, 0]

x = [23, 54, 81, 30, 48, 70, 53]
y = [35, 35, 35, 49, 49, 49, 63]
xmove = [20, 20, 20, 18, 18, 18, 22]


up = machine.Pin(2, machine.Pin.IN, machine.Pin.PULL_DOWN)
down = machine.Pin(3, machine.Pin.IN, machine.Pin.PULL_DOWN)
back = machine.Pin(4, machine.Pin.IN, machine.Pin.PULL_DOWN)
enter = machine.Pin(5, machine.Pin.IN, machine.Pin.PULL_DOWN)
mode = 1
flag = True

activeButtons = [False, False, False, False]
alarmStatus = False
alarmSound = False
stopAlarm = False
alarmString = "OFF"
Max = 1000
Min = 0
timeSlot = 0
count = 0
alarmTime = ()
timeSet = ()
alarmSetFlag = False
marker = 0

buzzer = machine.PWM(machine.Pin(22))


i2c1 = machine.I2C(1, scl=machine.Pin(15), sda=machine.Pin(14), freq=400000)
i2c2 = machine.I2C(0, scl=machine.Pin(1), sda=machine.Pin(0), freq=400000)

RTC = DS3231(i2c1)
currentTime = RTC.datetime()
ListTime = []
oled = ssd1306.SSD1306_I2C(WIDTH, HEIGHT, i2c2)

gfx = GFX(128, 64, oled.pixel)

write1 = Write(oled, bookerly_12)
write2 = Write(oled, bookerly_15)
write3 = Write(oled, bookerly_20)

oled.show()

def StarWars():
    global song
    global song_pos
    global stopAlarm
    global alarmSound
    global activeButtons
    
    while True:
        
        spLock.acquire()
        
        
        if alarmSound == True:
            
            
            if song[song_pos] > 0:
                buzzer.duty_u16(500)
                buzzer.freq(song[song_pos])
                song_pos = song_pos + 1
                time.sleep(song[song_pos]/100*60)
                song_pos = song_pos + 1
            else:
                buzzer.duty_u16(0)
                song_pos = song_pos + 1
                time.sleep(song[song_pos])
                song_pos = song_pos + 1
            if song_pos >= len(song):
                song_pos = 0
                
        if activeButtons[0] == True or activeButtons[1] == True or activeButtons[2] == True or activeButtons [3] == True:
                alarmSound = False
                
                song_pos = 0
                buzzer.duty_u16(0)
               
        spLock.release()
            
            
def DisplayTime():
    
    global alarmStatus
    global stringTime
    global mode
    global alarmSetFlag
    global ListTime
    
    ButtonCheck()
    
    if alarmSetFlag == True:
        if activeButtons[0] == True:
            SwitchAlarm()
    if activeButtons[3] == True:
        mode = 2
    if activeButtons[2] == True:
        mode = 3
        
    GetStringTime(ListTime)

    write1.text("ALARM : " + alarmString, 29,0)   
    write3.text(stringTime[4] + ":" + stringTime[5] + ":" + stringTime[6],22, 12)
    write1.text(stringTime[3] + "  " + stringTime[2] + " " + stringTime[1]  ,29, 35)
    write1.text(stringTime[0], 51, 50)
    stringTime = []
    if alarmStatus == True:
        CheckAlarm()
    stringTime = []
    ListTime = []
    
   

def CheckAlarm():
    global alarmSound
    alarm = RTC.check_alarm(1) 
    if alarm == True and alarmSound == False:
     
        alarmSound = True
        

def SetTime():
    global ListTime
    global mode
    global stringTime
    global timeSlot
    global Min
    global Max
    global timeSlotOrder
    global count
    global flag
    global timeSet
    global ListTime
  
    
    if flag:
        timeSet = ListTime
        flag = False
        count = 0
        
        
    timeSlot =  timeSlotOrder[count]  
    timeSet = SetDateMax(timeSet)
    Min = minimum[timeSlot]
    Max = maximum[timeSlot]
        
    ButtonCheck()
    
    GetStringTime(timeSet)
      
    write1.text("SET TIME AND DATE", 10,0)   
    write3.text(stringTime[4] + ":" + stringTime[5] + ":" + stringTime[6],22, 12)
    write1.text(stringTime[3] + "  " + stringTime[2] + " " + stringTime[1]  ,29, 35)
    write1.text(stringTime[0], 51, 50)
    oled.hline(x[count], y[count], xmove[count], 1)
    
    stringTime = []
    ListTime = []
    
    if activeButtons[0] == True:
        if timeSlot == 6:
            timeSet[timeSlot] = 0
        else:
            timeSet[timeSlot] = ButtonScrollUp(Min, Max, timeSet[timeSlot])
        
    if activeButtons[1] == True:
        if timeSlot == 6:
            timeSet[timeSlot] = 0
        else:
            timeSet[timeSlot] = ButtonScrollDown(Min, Max, timeSet[timeSlot])
        
       
    if activeButtons[2] == True:
        if count == 6:
            count = 0
        else:
            count = count + 1
    
    
    if activeButtons[3] == True:
        mode = 1
        flag = True
        count = 0
        setTimeTuple = (timeSet[0], timeSet[1], timeSet[2], timeSet[4], timeSet[5], timeSet[6], timeSet[3])
        RTC.datetime(setTimeTuple)
    
    
    
def SetAlarm():
    global currentTime
    global mode
    global stringTime
    global timeSlot
    global flag
    global Min
    global Max
    global alarmTime
    global RTC
    global alarmSetFlag
    global count
    global ListTime
    
    Min = minimum[timeSlot]
    Max = maximum[timeSlot]
    
    
    if flag:
        if alarmSetFlag == False:
        
            alarmTime = ListTime
           
            
        timeSlot = 4
        flag = False
   
    
    GetStringTime(alarmTime)
   
    
    
    
    write1.text("SET ALARM", 29,0)   
    write3.text(stringTime[4] + ":" + stringTime[5],32, 12)
    
    
    
    ButtonCheck()
   
    if count == 0:
        oled.hline(33, 35, 20, 1)
    else:
        oled.hline(62, 35, 20, 1)
        
        
    stringTime = []
    ListTime = []
        
            
    if activeButtons[0] == True:
        alarmTime[timeSlot] = ButtonScrollUp(Min, Max, alarmTime[timeSlot])
        
    if activeButtons[1] == True:
        alarmTime[timeSlot] = ButtonScrollDown(Min, Max, alarmTime[timeSlot])
        
       
    if activeButtons[2] == True:
        if timeSlot == 5:
            timeSlot = 4
            count = 0
        else:
            timeSlot = timeSlot + 1
            count = 1
    
    if activeButtons[3] == True:
        mode = 1
        flag = True
        alarmSetFlag = True
        count = 0
        
        RTC.alarm1((0, alarmTime[5], alarmTime[4]), match=RTC.AL1_MATCH_HMS)
      
        
        
        
def SetDateMax(time):
    global maximum
    
    if time[1] == 2:
        if time[0] % 4 == 0:
            maximum[2] = 29
        else:
            maximum[2] = 28
    elif time[1] == 3 or 6 or 9 or 11:
        maximum[2] = 30
    else:
        maximum[2] = 31
        
    if time[2] > maximum[2]:
        time[2] = maximum[2]
        
    return time
    
        
def GetStringTime(time):
    
    global stringTime
    
    for number, item in enumerate(time):
        if item < 10:
           stringTime.insert(number,"0" + str(item)) 
        else:
            
           stringTime.insert(number, str(item))
            
    stringTime[3] = days[time[3]-1]
    stringTime[1] = months[time[1]-1]
    
        
def ButtonScrollUp(Min, Max, timePart):
    
    if timePart == Max:
        timePart = Min
    else:
        timePart = timePart + 1
    
    return timePart

    
def ButtonScrollDown(Min, Max, timePart):
    
    if timePart == Min:
        timePart = Max
    else:
        timePart = timePart - 1
        
    return timePart

    
def ButtonCheck():
    global activeButtons
    global up
    global down
    global back
    global enter
    global stopAlarm
    
            
    if up.value():
        time.sleep(0.1)
        if up.value():
            activeButtons[0] = True
            buzzer.freq(500)
            buzzer.duty_u16(500)
            time.sleep(0.1)
            buzzer.duty_u16(0)
    else:
        activeButtons[0] = False
        
    if down.value():
        time.sleep(0.1)
        if down.value():
            activeButtons[1] = True
            buzzer.freq(600)
            buzzer.duty_u16(500)
            time.sleep(0.1)
            buzzer.duty_u16(0)
    else:
        activeButtons[1] = False
            
    if back.value():
        time.sleep(0.1)
        if back.value():
            activeButtons[2] = True
            buzzer.freq(700)
            buzzer.duty_u16(500)
            time.sleep(0.1)
            buzzer.duty_u16(0)
    else:
        activeButtons[2] = False
        
    if enter.value():
        time.sleep(0.1)
        if enter.value():
            activeButtons[3] = True
            buzzer.freq(800)
            buzzer.duty_u16(500)
            time.sleep(0.1)
            buzzer.duty_u16(0)
    else:
        activeButtons[3] = False
        
def ConvertTime(time):
    global ListTime
    
    for number, item in enumerate(time):
        
        ListTime.insert(number,item) 
       
def Main():
   
   spLock.acquire() 
   currentTime = RTC.datetime()
   ConvertTime(currentTime)
   oled.fill(0)
   
   if mode == 1:
       DisplayTime()
   elif mode == 2:
       SetAlarm()
   elif mode == 3:
       SetTime()
       


   
   oled.show()
   stringTime = []
   ListTime = []
   spLock.release()


            
def SwitchAlarm():
    global alarmString
    global alarmStatus
    
    alarmStatus = not alarmStatus
    
    if alarmStatus == True:
        alarmString = "ON"
    else:
        alarmString = "OFF"

_thread.start_new_thread(StarWars, ())

while True:
   
   Main()